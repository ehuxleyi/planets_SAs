
% This script sets the duration that the planet needs to stay habitable
% for, on this rerun, in order for there to be enough for evolution to
% produce intelligence
%--------------------------------------------------------------------------

% make it random between 0.5 and 10.0 By
max_duration = 0.5e6 + (9.5e6 * rand);  % rand is between 0 and 1
